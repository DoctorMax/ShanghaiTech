# -*- coding: utf-8 -*-
"""
Created on Wed Nov  4 19:37:28 2020

@author: aiwan
"""
import torch
import torchvision
import torch.utils.data as Data
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from torch.utils.data import DataLoader
import time

import os
import sys
import numpy as np
import pandas as pd

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from torch import optim



starttime = time.time()

torch.manual_seed(1)
EPOCH = 10
BATCH_SIZE = 64
LR = 1e-4
N_TEST_IMG = 5


dataset = np.load('counts.npy')
labels = np.loadtxt("labels.txt")
dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)


# print(train_data.train_data.size())
# print(train_data.train_labels.size())
# # print(train_data.train_data[0])
# plt.imshow(train_data.train_data[2].numpy(),cmap='Greys')
# plt.title('%i'%train_data.train_labels[2])
# plt.show()
def return_out_mask(batch_data):
    '''
    Input: NxM np.array of counts data
    Output: NxM np.array filled with 1 corresponding to non-zero inputs
            and 0 corresponding to dropped inputs
    '''
    batch_data_numpy = batch_data.numpy()
    zero_indices = np.nonzero(batch_data_numpy == 0)
    mask = np.ones_like(batch_data_numpy)
    zeros = np.zeros_like(batch_data_numpy)
    mask[zero_indices] = zeros[zero_indices] # Fills in 0's into appropriate indices
    mask_torch  = torch.from_numpy(mask)
    return mask_torch

class AutoEncoder(nn.Module):
    def __init__(self):
        super(AutoEncoder,self).__init__()
        self.encoder  =  nn.Sequential(
            nn.Linear(1000,500),
            nn.Tanh(),
            nn.Linear(500,100),
            nn.Tanh(),   
            nn.Linear(100,10),
        )
        
        self.decoder = nn.Sequential(
            nn.Linear(10,100),
            nn.Tanh(),
            nn.Linear(100,500),
            nn.Tanh(),
            nn.Linear(500,1000),
        )
    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded).mul(return_out_mask(x))
        return encoded, decoded



Coder = AutoEncoder()
print(Coder)

optimizer = torch.optim.Adam(Coder.parameters(),lr=LR)
loss_func = nn.MSELoss()


for epoch in range(EPOCH):
    for step, x in enumerate(dataloader):
        print('step:',step)
        print('xsize:',x.size())
        
        b_x = x.view(-1,1000)
        #print(b_x.size())
        #b_mask = return_out_mask(b_x)
        # b_y = x.view(-1,1000)
        #b_label = y
        encoded, decoded = Coder(b_x)
        #decoded = decoded.mul(return_out_mask(x))
        loss = loss_func(decoded, b_x)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        #if step%5 == 0:
            #print('Epoch :', epoch,'|','train_loss:%.4f'%loss.data)

torch.save(Coder,'AutoEncoder.pkl')
print('________________________________________')
print('finish training')

endtime = time.time()
print('训练耗时：',(endtime - starttime))


#Coder = AutoEncoder()
Coder = torch.load('AutoEncoder.pkl')

'''
# T-SNE & PCA Plot of Counts Data
tsne_data = TSNE(n_components=2).fit_transform(dataset)
plt.scatter(tsne_data[:,0],tsne_data[:,1],c=labels,s=3)
plt.title('data_tsne')
plt.show()

pca = PCA(n_components=2)
pca_data = pca.fit_transform(dataset)
plt.scatter(pca_data[:,0],pca_data[:,1],c=labels,s=3)
plt.title('data_pca')
plt.show()
'''


'''
# T-SNE & PCA Plot of Encodings
#####################################################
dataset_tensor=torch.from_numpy(dataset)
encoded_data, decoded_data =Coder(dataset_tensor)# np.array
encoded_data_numpy=encoded_data.detach().numpy()
decoded_data_numpy=decoded_data.detach().numpy()
#####################################################

tsne_latent = TSNE(n_components=2).fit_transform(encoded_data_numpy)
plt.scatter(tsne_latent[:,0],tsne_latent[:,1],c=labels,s=3)
plt.title('encoded_tsne')
plt.show()

pca = PCA(n_components=2)
pca_data = pca.fit_transform(encoded_data_numpy)
plt.scatter(pca_data[:,0],pca_data[:,1],c=labels,s=3)
plt.title('encoded_pca')
plt.show()

# T-SNE & PCA Plot of Reconstructions
#####################################################
reconstructions= decoded_data_numpy
#####################################################
tsne_latent = TSNE(n_components=2).fit_transform(reconstructions)
plt.scatter(tsne_latent[:,0],tsne_latent[:,1],c=labels,s=3)
plt.title('reconstructed_tsne')
plt.show()

pca = PCA(n_components=2)
pca_data = pca.fit_transform(reconstructions)
plt.scatter(pca_data[:,0],pca_data[:,1],c=labels,s=3)
plt.title('reconstructed_pca')
plt.show()
'''





















'''
#数据的空间形式的表示
view_data = train_data.train_data[:200].view(-1, 28*28).type(torch.FloatTensor)/255.
encoded_data, _ = Coder(view_data)    # 提取压缩的特征值
fig = plt.figure(2)
ax = Axes3D(fig)    # 3D 图
# x, y, z 的数据值
X = encoded_data.data[:, 0].numpy()
Y = encoded_data.data[:, 1].numpy()
Z = encoded_data.data[:, 2].numpy()
# print(X[0],Y[0],Z[0])
values = train_data.train_labels[:200].numpy()  # 标签值
for x, y, z, s in zip(X, Y, Z, values):
    c = cm.rainbow(int(255*s/9))    # 上色
    ax.text(x, y, z, s, backgroundcolor=c)  # 标位子
ax.set_xlim(X.min(), X.max())
ax.set_ylim(Y.min(), Y.max())
ax.set_zlim(Z.min(), Z.max())
plt.show()
'''

#原数据和生成数据的比较
'''
plt.ion()
plt.show()


for i in range(10):
    test_data = train_data.train_data[i].view(-1,28*28).type(torch.FloatTensor)/255.
    _,result = Coder(test_data)

    # print('输入的数据的维度', train_data.train_data[i].size())
    # print('输出的结果的维度',result.size())
    
    im_result = result.view(28,28)
    # print(im_result.size())
    plt.figure(1, figsize=(10, 3))
    plt.subplot(121)
    plt.title('test_data')
    plt.imshow(train_data.train_data[i].numpy(),cmap='Greys')

    plt.figure(1, figsize=(10, 4))
    plt.subplot(122)
    plt.title('result_data')
    plt.imshow(im_result.detach().numpy(), cmap='Greys')
    plt.show()
    plt.pause(0.5)

plt.ioff()
'''