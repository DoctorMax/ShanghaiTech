---
name: Task-specific VoxelMorph question
about: Questions about how to use VoxelMorph specific to your task
title: ''
labels: ''
assignees: ''

---

**Task** (what are you trying to do/register?)

[please describe task here]

**What have you tried**

Please describe specifics of your approach // use of `vxm`

**Details of experiments**

Please carefully specify details about your experiments. If you are training, when what is the setup? What loss are you using? What does the convergence look like? If you are registering, please show example inputs and outputs. etc.
