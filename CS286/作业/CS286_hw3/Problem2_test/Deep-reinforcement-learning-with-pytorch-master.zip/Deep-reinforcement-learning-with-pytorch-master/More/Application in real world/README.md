# This repo we introduce some application in real world


This [post](https://towardsdatascience.com/advanced-reinforcement-learning-6d769f529eb3) would give you an idea of the application of reinforcement learning in industry.

Here I upload some papers about this topic. 
