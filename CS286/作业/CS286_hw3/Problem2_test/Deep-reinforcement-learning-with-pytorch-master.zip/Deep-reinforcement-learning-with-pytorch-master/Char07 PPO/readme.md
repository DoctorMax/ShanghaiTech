# PPO

- Original paper: https://arxiv.org/abs/1707.06347
- Openai Baselines blog post: https://blog.openai.com/openai-baselines-ppo/

Notice: This is not the author's implementation! 
