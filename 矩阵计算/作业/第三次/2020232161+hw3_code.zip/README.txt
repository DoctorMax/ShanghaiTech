Problem2:
	code: 
		sol2_1_gradientdecent.m
		sol2_2_normalequation.m
	answer: 
		sol1.txt
		sol2.txt
Peoblem3:
	code:
		sol3_1_classicalGramSchmidt.m
		sol3_2_modifiedGramSchmidt.m
	